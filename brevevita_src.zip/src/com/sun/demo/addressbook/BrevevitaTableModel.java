/*
 * BrevevitaTableModel.java
 *
 * Created on 9 marzo 2008, 17.09
 *
 *  aliCE (c) 2007-2008
 *  Michele Piunti
 */

package com.sun.demo.addressbook;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author michelepiunti
 */
public class BrevevitaTableModel extends DefaultTableModel {
    
    /** Creates a new instance of BrevevitaTableModel */
    public BrevevitaTableModel() {
        super();
    }
    
}
