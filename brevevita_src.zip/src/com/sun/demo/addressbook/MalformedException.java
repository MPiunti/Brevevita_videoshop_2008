/*
 * MalformedException.java
 *
 * Created on 16 marzo 2008, 12.54
 *
 *  aliCE (c) 2007-2008
 *  Michele Piunti
 */

package com.sun.demo.addressbook;

/**
 *
 * @author michelepiunti
 */
public class MalformedException extends Exception {
    
    /** Creates a new instance of MalformedException */
    public MalformedException() {
    }
    
}
